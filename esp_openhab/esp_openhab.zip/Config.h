String ssidAP="esp8266";
String passwordAP = "12345678";
int led_pin=2;

//String ssidCLI="AndroidAP50DB";
//String passwordCLI="gkzf1590";

String ssidCLI="Honor 8X";
String passwordCLI="387008179";

const bool MODE_AP=false;

const char * mqtt_broker="broker.emqx.io";
int mqtt_port=1883;

String client_id="MQTTNOTSET";
